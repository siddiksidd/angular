import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-siddik',
  templateUrl: './siddik.component.html',
  styleUrls: ['./siddik.component.css']
})
export class SiddikComponent {

  name:string='siddik';
  age:number=21;

  Customer={
    customerName:'prem',
    customerId:1001,
    accountonHold:true
  }
}
