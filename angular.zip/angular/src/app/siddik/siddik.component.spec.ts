import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SiddikComponent } from './siddik.component';

describe('SiddikComponent', () => {
  let component: SiddikComponent;
  let fixture: ComponentFixture<SiddikComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SiddikComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SiddikComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
