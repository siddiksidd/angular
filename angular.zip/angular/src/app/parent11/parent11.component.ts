import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent11',
  templateUrl: './parent11.component.html',
  styleUrls: ['./parent11.component.css']
})
export class Parent11Component  {

  title = 'Assignment 11';
  Counter = 1000;
 
  countChangedHandler(count: number) {
    this.Counter = count;
    console.log(count);
  }

}
