import { SearchpipePipe } from './searchpipe.pipe';

describe('SearchpipePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchpipePipe();
    expect(pipe).toBeTruthy();
  });
});
