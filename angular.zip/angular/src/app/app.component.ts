import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.Component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular';
}
