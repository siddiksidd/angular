import { SortpipePipe } from './sortpipe.pipe';

describe('SortpipePipe', () => {
  it('create an instance', () => {
    const pipe = new SortpipePipe();
    expect(pipe).toBeTruthy();
  });
});
