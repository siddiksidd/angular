import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-i18-n',
  templateUrl: './i18-n.component.html',
  styleUrls: ['./i18-n.component.css']
})
export class I18NComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
