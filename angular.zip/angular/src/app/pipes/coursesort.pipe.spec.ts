import { CoursesortPipe } from './coursesort.pipe';

describe('CoursesortPipe', () => {
  it('create an instance', () => {
    const pipe = new CoursesortPipe();
    expect(pipe).toBeTruthy();
  });
});
