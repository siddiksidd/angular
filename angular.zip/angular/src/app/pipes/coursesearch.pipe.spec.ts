import { CoursesearchPipe } from './coursesearch.pipe';

describe('CoursesearchPipe', () => {
  it('create an instance', () => {
    const pipe = new CoursesearchPipe();
    expect(pipe).toBeTruthy();
  });
});
