import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-assignment7',
  templateUrl: './assignment7.component.html',
  styleUrls: ['./assignment7.component.css']
})
export class Assignment7Component  {

  filteredString:string='';
  sortby: any='1'
  products:any;
  // constructor(private productServices:ProductService)
  // {
  //   this.products=productServices.getallproducts();      8assignment calling from service
  // }
  // products = [
  //   {productId:101,productName:"samsung s20 ultra", productPrice:'12000',productDesc:"Samusung Mobile",productImg:'assets/images/img4.jpg'},
  //   {productId:102,productName:"Apple iphone 12 pro", productPrice:'100000',productDesc:"Iphone Mobile",productImg:'assets/images/img1.jpg'},
  //   {productId:103,productName:"onePlus 9 pro", productPrice:'69000',productDesc:"Oneplus Mobile",productImg:'assets/images/img2.jpg'},
  //   {productId:104,productName:"asus rogphone 5", productPrice:'50000',productDesc:"Asus Mobile",productImg:'assets/images/img3.jpg'}    //general calling

  // ]

  errMsg:any;
  constructor(proService:ProductService){
    proService.getallproducts().subscribe(
      result => this.products = result,      //10assignment calling from json and service
      error => this.errMsg = error
    )
}
}
