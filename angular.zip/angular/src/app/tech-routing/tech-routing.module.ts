import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { WebComponent } from '../web/web.component';
import { JavaComponent } from '../java/java.component';
import { CorejavaComponent } from '../corejava/corejava.component';
import { AdvjavaComponent } from '../advjava/advjava.component';
import { CorewebComponent } from '../coreweb/coreweb.component';
import { AdvwebComponent } from '../advweb/advweb.component';
import { Assignment7Component } from '../assignment7and8/assignment7.component';
import { ReactFormsComponent } from '../react-forms/react-forms.component';
import { TempDrivenFormsComponent } from '../temp-driven-forms/temp-driven-forms.component';
const routes:Routes = [
  {path:'web', component:WebComponent, 
  children:[
    {path:'coreweb', component:CorewebComponent },
    {path:'advweb', component:AdvwebComponent},
   ] },
  {path:'java', component:JavaComponent,
   children:[
    {path:'corejava', component:CorejavaComponent },
    {path:'advjava', component:AdvjavaComponent}
   ]
 },
  { path:'Products', component:Assignment7Component},
  { path:'react-form', component:ReactFormsComponent},
  { path:'temp-driven-form', component:TempDrivenFormsComponent}
]

children:[
  {path:'corejava', component:CorejavaComponent },
  {path:'advjava', component:AdvjavaComponent},
  {path:'corejava', component:CorejavaComponent },
  {path:'advjava', component:AdvjavaComponent}
 ]
 

@NgModule({
  declarations: [],
  imports: [
    CommonModule, RouterModule.forRoot(routes)
  ],
  exports:[RouterModule]
})
export class TechRoutingModule { }
export const routingComponents = [WebComponent,JavaComponent,Assignment7Component,ReactFormsComponent,TempDrivenFormsComponent]
