import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent  {

  products = [
    {productId:101,productName:"samsung s20ultra", productPrice:'12000',productDesc:"Samusung Mobile",productImg:'assets/images/img4.jpg'},
    {productId:102,productName:"iphone 12pro", productPrice:'100000',productDesc:"Iphone Mobile",productImg:'assets/images/img1.jpg'}]}