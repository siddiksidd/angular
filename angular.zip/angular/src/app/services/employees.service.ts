// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class EmployeesService {

//   constructor() { }
//   getEmployeesInfo(){
//     return  [
//       {empId:101, empName:'siddik'},
//       {empId:102, empName:'prem'},
//     ]
//   }
// }
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {
  url:string = 'assets/employees1.json'; //local
  //url:string = ''; //network RESTful
  constructor(private httpClient:HttpClient) { }
  getEmployeesInfo(){
     return this.httpClient.get(this.url)
  }
}


