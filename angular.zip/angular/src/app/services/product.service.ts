import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
 
  // products = [
  //   {productId:101,productName:"samsung s20 ultra", productPrice:'12000',productDesc:"Samusung Mobile",productImg:'assets/images/img4.jpg'},
  //   {productId:102,productName:"Apple iphone 12 pro", productPrice:'100000',productDesc:"Iphone Mobile",productImg:'assets/images/img1.jpg'},
  //   {productId:103,productName:"onePlus 9 pro", productPrice:'69000',productDesc:"Oneplus Mobile",productImg:'assets/images/img2.jpg'},
  //   {productId:104,productName:"asus rogphone 5", productPrice:'50000',productDesc:"Asus Mobile",productImg:'assets/images/img3.jpg'}
//assignmnet 8
  // ]
  

  url:string = 'assets/products.json'; //local
  //url:string = ''; //network RESTful
  constructor(private httpClient:HttpClient) { }
  getallproducts(){
     return this.httpClient.get(this.url)
  }

  
}
