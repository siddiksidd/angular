import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';


import { AppComponent } from './app.component';
import { SiddikComponent } from './siddik/siddik.component';
import { CalculatorComponent } from './calculator/calculator.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ProductsComponent } from './products/products.component';
import { PropertyBindingComponent } from './property-binding/property-binding.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TwowayBindingComponent } from './twoway-binding/twoway-binding.component';
import { EventBindingComponent } from './event-binding/event-binding.component';
import { StructDirectivesComponent } from './struct-directives/struct-directives.component';
import { SearchpipePipe } from './searchpipe.pipe';
import { Assignment7Component } from './assignment7and8/assignment7.component';
import { SortpipePipe } from './sortpipe.pipe';
import { ColorDirectiveDirective } from './directives/color-directive.directive';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { Parent11Component } from './parent11/parent11.component';
import { Child11Component } from './child11/child11.component';
import { Assignment9Component } from './assignment9/assignment9.component';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';

import { routingComponents, TechRoutingModule } from './tech-routing/tech-routing.module';
import { CoursesearchPipe } from './pipes/coursesearch.pipe';
import { CoursesortPipe } from './pipes/coursesort.pipe';
import { CorejavaComponent } from './corejava/corejava.component';
import { AdvjavaComponent } from './advjava/advjava.component';
import { First1Component } from './first1/first1.component';
import { Second1Component } from './second1/second1.component';
import { ReactFormsComponent } from './react-forms/react-forms.component';
import { TempDrivenFormsComponent } from './temp-driven-forms/temp-driven-forms.component';
import { CorewebComponent } from './coreweb/coreweb.component';
import { AdvwebComponent } from './advweb/advweb.component';
import { I18NComponent } from './i18-n/i18-n.component';




@NgModule({
  declarations: [
    AppComponent,
    SiddikComponent,
    CalculatorComponent,
    ProductsComponent,
    PropertyBindingComponent,
    TwowayBindingComponent,
    EventBindingComponent,
    StructDirectivesComponent,
  
    SearchpipePipe,
    Assignment7Component,
   
    SortpipePipe,
         ColorDirectiveDirective,
         ParentComponent,
         ChildComponent,
         Parent11Component,
         Child11Component,
         Assignment9Component,
         FirstComponent,
         SecondComponent,
         
         routingComponents,
                   CoursesearchPipe,
                   CoursesortPipe,
                   CorejavaComponent,
                   AdvjavaComponent,
                   First1Component,
                   Second1Component,
                   ReactFormsComponent,
                   TempDrivenFormsComponent,
                   CorewebComponent,
                   AdvwebComponent,
                   I18NComponent
                   
         
    
  ],
  imports: [
    BrowserModule,
    
    FormsModule,
    HttpClientModule,
    TechRoutingModule, ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
