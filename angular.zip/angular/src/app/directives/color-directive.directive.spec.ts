import { ColorDirectiveDirective } from './color-directive.directive';

describe('ColorDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new ColorDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
