import { Component, OnInit } from '@angular/core';
import { CalcService } from '../services/calc.service';

@Component({
  selector: 'app-assignment9',
  templateUrl: './assignment9.component.html',
  styleUrls: ['./assignment9.component.css']
})
export class Assignment9Component  {
  number1:any;
  number2:any;
  number3:any;
  result:any;
  value:any;

  constructor(private calculatorService:CalcService)
  {
    
  }
  operation(value:any)
  {
    var value1=(Number)(this.number1)
    var value2=(Number)(this.number2)
    var value3=(Number)(this.number3)
    this.number3=this.calculatorService.getResult(value1,value2,value3,value)
  }

}
