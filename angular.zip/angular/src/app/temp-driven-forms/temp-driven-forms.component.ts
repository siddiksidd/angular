import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-temp-driven-forms',
  templateUrl: './temp-driven-forms.component.html',
  styleUrls: ['./temp-driven-forms.component.css']
})
export class TempDrivenFormsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  submitData(value:any) {
    console.log(value)
 

  }
}
