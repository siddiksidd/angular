import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child11',
  templateUrl: './child11.component.html',
  styleUrls: ['./child11.component.css']
})
export class Child11Component  {

  @Input() count:any;
 
  @Output() countChanged: EventEmitter<number> =   new EventEmitter();

  mutualFund() {
      this.count++;
      this.countChanged.emit(this.count);
    }
  stockMarket() {
      this.count--;
      this.countChanged.emit(this.count);
  }

}
